package com.intrepid.MealTrackerPilot.views;

import android.os.Bundle;

import com.intrepid.MealTrackerPilot.R;

import androidx.appcompat.app.AppCompatActivity;


public class RetroFitRoomActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_retro_fit_room);
        getSupportFragmentManager().beginTransaction().replace(R.id.container_retro_room,new RetroFitPostFragment()).commit();
    }
}
