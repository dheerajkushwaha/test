package com.intrepid.MealTrackerPilot.viewmodels;


import androidx.lifecycle.ViewModel;

public class UserInfoViewModel extends ViewModel {
}
