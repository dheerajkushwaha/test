package com.intrepid.MealTrackerPilot.data.local.db;

import android.app.Application;
import android.os.AsyncTask;

import com.intrepid.MealTrackerPilot.data.local.db.dao.PostInfoDao;
import com.intrepid.MealTrackerPilot.data.local.db.entity.ResultModel;

import java.util.List;

import androidx.lifecycle.LiveData;

public class PostRoomDBRepository {
    private PostInfoDao postInfoDao;
    LiveData<List<ResultModel>> mAllPosts;

    public PostRoomDBRepository(Application application) {
        PostInfoRoomDataBase db = PostInfoRoomDataBase.getDatabase(application);
        postInfoDao = db.postInfoDao();
        mAllPosts = postInfoDao.getAllPosts();
    }

    public LiveData<List<ResultModel>> getAllPosts() {
        return mAllPosts;
    }

    public void insertPosts(List<ResultModel> resultModel) {
        new insertAsyncTask(postInfoDao).execute(resultModel);
    }

    private static class insertAsyncTask extends AsyncTask<List<ResultModel>, Void, Void> {

        private PostInfoDao mAsyncTaskDao;

        insertAsyncTask(PostInfoDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final List<ResultModel>... params) {
            mAsyncTaskDao.insertPosts(params[0]);
            return null;
        }
    }
}
