package com.intrepid.MealTrackerPilot.data.remote.interceptor.api;

public class APIUrl {
    public static final String BASE_URL = "https://jsonplaceholder.typicode.com/";
}
