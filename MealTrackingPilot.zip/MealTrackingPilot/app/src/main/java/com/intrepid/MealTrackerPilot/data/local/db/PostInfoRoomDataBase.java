package com.intrepid.MealTrackerPilot.data.local.db;


import android.content.Context;

import com.intrepid.MealTrackerPilot.data.local.db.dao.PostInfoDao;
import com.intrepid.MealTrackerPilot.data.local.db.entity.ResultModel;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities = {ResultModel.class}, version = 1)
public abstract class PostInfoRoomDataBase extends RoomDatabase {
    public abstract PostInfoDao postInfoDao();
    private static PostInfoRoomDataBase INSTANCE;
    static PostInfoRoomDataBase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (PostInfoRoomDataBase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            PostInfoRoomDataBase.class, "postinfo_database")
                            .addCallback(sRoomDatabaseCallback)
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    private static Callback sRoomDatabaseCallback =
            new Callback(){

                @Override
                public void onOpen (@NonNull SupportSQLiteDatabase db){
                    super.onOpen(db);
                    new PopulateDbAsync(INSTANCE).execute();
                }
            };
}
