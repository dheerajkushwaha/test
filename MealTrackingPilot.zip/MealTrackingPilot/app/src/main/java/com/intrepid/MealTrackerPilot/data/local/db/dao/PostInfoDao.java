package com.intrepid.MealTrackerPilot.data.local.db.dao;


import com.intrepid.MealTrackerPilot.data.local.db.entity.ResultModel;

import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

@Dao
public interface PostInfoDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(ResultModel resultModel);

    @Query("SELECT * from post_info ORDER BY id ASC")
    LiveData<List<ResultModel>> getAllPosts();

    @Query("DELETE FROM post_info")
    void deleteAll();


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertPosts(List<ResultModel> resultModel);

}
