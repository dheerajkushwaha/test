package com.intrepid.MealTrackerPilot.viewmodels;

import android.app.Application;

import com.intrepid.MealTrackerPilot.data.local.db.PostRoomDBRepository;
import com.intrepid.MealTrackerPilot.data.local.db.entity.ResultModel;
import com.intrepid.MealTrackerPilot.data.remote.interceptor.repository.WebServiceRepository;

import java.util.List;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

public class PostsListViewModel extends AndroidViewModel {

    private PostRoomDBRepository postRoomDBRepository;
    private LiveData<List<ResultModel>> mAllPosts;
    WebServiceRepository webServiceRepository;
    private final LiveData<List<ResultModel>> retroObservable;

    public PostsListViewModel(Application application) {
        super(application);
        postRoomDBRepository = new PostRoomDBRepository(application);
        webServiceRepository = new WebServiceRepository(application);
        retroObservable = webServiceRepository.providesWebService();
        //postRoomDBRepository.insertPosts(retroObservable.getValue());
        mAllPosts = postRoomDBRepository.getAllPosts();

    }

    public LiveData<List<ResultModel>> getAllPosts() {
        return mAllPosts;
    }

   /* public LiveData<List<ResultModel>> getProjectRetroListObservable() {
        return retroObservable;
    }*/

/*    public void insert(User user) {
        userRepository.insert(user);
    }*/
}
