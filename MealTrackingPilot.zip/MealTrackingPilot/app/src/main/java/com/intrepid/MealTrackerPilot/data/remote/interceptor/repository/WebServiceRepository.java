package com.intrepid.MealTrackerPilot.data.remote.interceptor.repository;

import android.app.Application;
import android.util.Log;

import com.intrepid.MealTrackerPilot.data.local.db.entity.ResultModel;
import com.intrepid.MealTrackerPilot.data.remote.interceptor.api.APIService;
import com.intrepid.MealTrackerPilot.data.remote.interceptor.api.RetrofitClientInstance;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

import static android.content.ContentValues.TAG;

public class WebServiceRepository {

    Application application;
    private Retrofit retrofitClientInstance;
    private MutableLiveData<List<ResultModel>> data;

    public WebServiceRepository(Application application) {
        this.application = application;
    }

    private static OkHttpClient providesOkHttpClientBuilder() {

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
        return httpClient.readTimeout(1200, TimeUnit.SECONDS)
                .connectTimeout(1200, TimeUnit.SECONDS).build();

    }


    List<ResultModel> webserviceResponseList = new ArrayList<>();

    public MutableLiveData<List<ResultModel>> providesWebService() {

        retrofitClientInstance = RetrofitClientInstance.getRetrofitInstance();
        data = new MutableLiveData<>();

        APIService service = retrofitClientInstance.create(APIService.class);

        service.makeRequest().enqueue(new Callback<ResultModel>() {
            @Override
            public void onResponse(Call<ResultModel> call, Response<ResultModel> response) {
                if (response.isSuccessful()) {
                    List<ResultModel> resultModels=response.body();

                    data.setValue(response.message());//; = response.body();
                } else {
                    Log.e(TAG, "response not successful");
                }
            }

            @Override
            public void onFailure(Call<ResultModel> call, Throwable t) {
                Log.e(TAG, "response not successful");
            }
        });

        String response = "";
      /*  try {
            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(APIUrl.BASE_URL)
                   // .addConverterFactory(ScalarsConverterFactory.create())
                    .addConverterFactory(GsonConverterFactory.create())
                    .client(providesOkHttpClientBuilder())
                    .build();

            //Defining retrofit api service
            APIService service = retrofit.create(APIService.class);
            //  response = service.makeRequest().execute().body();
            service.makeRequest().enqueue(new Callback<String>() {
                @Override
                public void onResponse(Call<String> call, Response<String> response) {
                    Log.d("Repository", "Response::::" + response.body());
                    webserviceResponseList = parseJson(response.body());
                    PostRoomDBRepository postRoomDBRepository = new PostRoomDBRepository(application);
                    postRoomDBRepository.insertPosts(webserviceResponseList);
                    data.setValue(webserviceResponseList);
                }

                @Override
                public void onFailure(Call<String> call, Throwable t) {
                    Log.d("Repository", "Failed:::");
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }*/

        //  return retrofit.create(ResultModel.class);
        return data;

    }


    private List<ResultModel> parseJson(String response) {

        List<ResultModel> apiResults = new ArrayList<>();

        JSONObject jsonObject;

        JSONArray jsonArray;

        try {
            jsonArray = new JSONArray(response);

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject object = jsonArray.getJSONObject(i);

                ResultModel mMovieModel = new ResultModel();
                //mMovieModel.setId(object.getString("id"));
                mMovieModel.setId(Integer.parseInt(object.getString("id")));
                mMovieModel.setTitle(object.getString("title"));
                mMovieModel.setBody(object.getString("body"));

                apiResults.add(mMovieModel);
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }

        Log.i(getClass().getSimpleName(), String.valueOf(apiResults.size()));
        return apiResults;

    }
}
