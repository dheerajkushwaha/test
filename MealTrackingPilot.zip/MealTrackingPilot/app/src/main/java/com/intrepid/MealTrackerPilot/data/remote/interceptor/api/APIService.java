package com.intrepid.MealTrackerPilot.data.remote.interceptor.api;

import com.intrepid.MealTrackerPilot.data.local.db.entity.ResultModel;

import retrofit2.Call;
import retrofit2.http.GET;

public interface APIService {
    @GET("posts")
    Call<ResultModel> makeRequest();
}
