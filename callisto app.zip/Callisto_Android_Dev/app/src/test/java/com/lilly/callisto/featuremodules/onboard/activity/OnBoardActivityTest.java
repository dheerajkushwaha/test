package com.lilly.callisto.featuremodules.onboard.activity;

import android.app.Activity;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;

@RunWith(RobolectricTestRunner.class)
public class OnBoardActivityTest {
    private Activity activity;

    @Before
    public void setUp() throws Exception {
        activity = Robolectric.buildActivity(OnBoardActivity.class).create().resume().get();
    }

    @Test
    public void shouldNotBeNull() throws Exception {
        Assert.assertNotNull(activity);
    }
}
