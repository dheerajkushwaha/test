package com.lilly.callisto.featuremodules.onboard.activity;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.lilly.callisto.BR;
import com.lilly.callisto.R;
import com.lilly.callisto.base.BaseActivity;
import com.lilly.callisto.databinding.ActivityOnboardBinding;

public class OnBoardActivity extends BaseActivity<OnBoardViewModel, ActivityOnboardBinding> {
    private NavController mNavController;

    @Override
    protected void initViews() {
        mNavController = Navigation.findNavController(this, R.id.navhost_onboard);
    }

    @Override
    protected int getBindingVariable() {
        return BR.onBoardVM;
    }

    @Override
    protected Class getViewModelClass() {
        return OnBoardViewModel.class;
    }

    @Override
    protected int getLayoutRef() {
        return R.layout.activity_onboard;
    }
}
