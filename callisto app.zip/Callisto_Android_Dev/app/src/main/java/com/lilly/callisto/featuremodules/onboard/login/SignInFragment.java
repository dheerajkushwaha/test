package com.lilly.callisto.featuremodules.onboard.login;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.lilly.callisto.BR;
import com.lilly.callisto.R;
import com.lilly.callisto.base.BaseFragment;
import com.lilly.callisto.databinding.FragmentSigninBinding;

public class SignInFragment extends BaseFragment<SignInViewModel, FragmentSigninBinding>
        implements View.OnClickListener{

    private Button mSignInButton;

    @Override
    protected void initViews() {
        mSignInButton = mViewDataBinding.buttonSignin;
        mSignInButton.setOnClickListener(this);
    }

    @Override
    protected int getBindingVariable() {
        return BR.signInVM;
    }

    @Override
    protected Class getViewModelClass() {
        return SignInViewModel.class;
    }

    @Override
    protected int getLayoutRef() {
        return R.layout.fragment_signin;
    }

    @Override
    public void onClick(View view) {
        NavController navController = Navigation.findNavController(view);
        if(view.getId() == R.id.button_signin){
            navController.navigate(R.id.action_signin_to_terms_and_condition);
        }
    }
}
