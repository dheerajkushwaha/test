package com.lilly.callisto.comman.model;

public class SignInResModel {

    private UserResModel user;
    private CredentialsResModel credentials;

    public UserResModel getUser() {
        return user;
    }

    public CredentialsResModel getCredentials() {
        return credentials;
    }

    public void setUser(UserResModel user) {

        this.user = user;
    }

    public void setCredentials(CredentialsResModel credentials) {

        this.credentials = credentials;
    }
}
