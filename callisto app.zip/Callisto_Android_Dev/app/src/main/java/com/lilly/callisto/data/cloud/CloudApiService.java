package com.lilly.callisto.data.cloud;

import com.lilly.callisto.comman.model.SignInReqModel;
import com.lilly.callisto.comman.model.SignInResModel;

import io.reactivex.Single;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface CloudApiService {
    //login api
    @POST("users")
    Single<SignInResModel> signIn(@Body SignInReqModel signInRequestModel);
}
