package com.lilly.callisto.featuremodules.onboard.termsandconditions;

import androidx.lifecycle.ViewModel;

public class TermsAndConditionViewModel extends ViewModel  {


}
