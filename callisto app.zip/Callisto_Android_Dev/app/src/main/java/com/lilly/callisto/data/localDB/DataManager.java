package com.lilly.callisto.data.localDB;

/**
 * This class is acts as interface to call Database to perform DB operation
 */
public class DataManager {
}
