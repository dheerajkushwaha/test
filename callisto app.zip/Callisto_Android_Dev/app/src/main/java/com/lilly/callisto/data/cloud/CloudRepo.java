package com.lilly.callisto.data.cloud;

import android.content.Context;
import android.util.Log;


import com.lilly.callisto.comman.model.SignInReqModel;
import com.lilly.callisto.comman.model.SignInResModel;
import com.lilly.callisto.comman.model.UserResModel;
import com.lilly.callisto.featuremodules.onboard.login.SignInViewModel;

import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import io.reactivex.Scheduler;
import io.reactivex.Single;
import io.reactivex.SingleObserver;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.observers.DisposableSingleObserver;
import io.reactivex.schedulers.Schedulers;

public class CloudRepo {
    private CloudApiService mCloudApiService;
    private MutableLiveData<SignInResModel> userResModelLiveData = null;
    private CompositeDisposable disposable = new CompositeDisposable();

    public CloudRepo(Context context) {
        mCloudApiService = CloudManager.getClient(context).create(CloudApiService.class);
    }

    public LiveData<SignInResModel> verifyUser(SignInReqModel signInReqModel) {

        disposable.add(mCloudApiService.signIn(signInReqModel)
                .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableSingleObserver<SignInResModel>() {
                    @Override
                    public void onSuccess(SignInResModel signInResModel) {
                        userResModelLiveData.postValue(signInResModel);
                    }

                    @Override
                    public void onError(Throwable e) {
                        userResModelLiveData.postValue(null);
                    }
                }));


        /*Single<SignInResModel> signInResModelRes = mCloudApiService.signIn(signInReqModel);
        signInResModelRes.subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new SingleObserver<SignInResModel>() {
                    @Override
                    public void onSubscribe(Disposable d) {
                        Log.i("onSubscribe", "onSubscribe");
                    }

                    @Override
                    public void onSuccess(SignInResModel signIn) {
                        Log.i("onSuccess", "onSuccess");
                        userResModelLiveData.setValue(signIn);
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.i("onError", "onError");
                    }
                });*/

        return userResModelLiveData;
    }
}
