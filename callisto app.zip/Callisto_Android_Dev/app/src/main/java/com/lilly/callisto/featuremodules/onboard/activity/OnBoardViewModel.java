package com.lilly.callisto.featuremodules.onboard.activity;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

public class OnBoardViewModel extends AndroidViewModel {
    private Application mApplication;

    public OnBoardViewModel(@NonNull Application application) {
        super(application);
        mApplication = application;
    }
}
