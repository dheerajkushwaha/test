package com.lilly.callisto.featuremodules.onboard.login;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

public class SignInViewModel extends AndroidViewModel {
    private Application mApplication;

    public SignInViewModel(@NonNull Application application) {
        super(application);
        mApplication = application;
    }
}
