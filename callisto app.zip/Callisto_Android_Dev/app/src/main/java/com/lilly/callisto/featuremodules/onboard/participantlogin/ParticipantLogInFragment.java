package com.lilly.callisto.featuremodules.onboard.participantlogin;

import android.view.View;
import android.widget.Button;

import com.lilly.callisto.BR;
import com.lilly.callisto.R;
import com.lilly.callisto.base.BaseFragment;
import com.lilly.callisto.databinding.FragmentParticipantLoginBinding;


/**
 *
 */
public class ParticipantLogInFragment extends BaseFragment<ParticipantLogInViewModel,
        FragmentParticipantLoginBinding> implements View.OnClickListener{

    private Button mLoginButton;

    @Override
    protected void initViews() {
       init();
       initObservers();
    }

    private void init() {
        mLoginButton = mViewDataBinding.buttonParticipantLogin;
        mLoginButton.setOnClickListener(this);
    }

    private void initObservers() {
        mViewModel.getLoginStatus().observe(this, status -> {
            if(status){
                // TODO: login success logic
            } else {
                mViewDataBinding.messageLayout.setBackground(getActivity().getDrawable(R.drawable.message_background_red));
                mViewDataBinding.messageText.setText(R.string.signin_fail_msg_txt);
            }
        });
    }

    @Override
    protected int getBindingVariable() {
        return BR.participantLoginVM;
    }

    @Override
    protected Class getViewModelClass() {
        return ParticipantLogInViewModel.class;
    }

    @Override
    protected int getLayoutRef() {
        return R.layout.fragment_participant_login;
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.button_participant_login){
            mViewModel.doLogin();
        }
    }
}
