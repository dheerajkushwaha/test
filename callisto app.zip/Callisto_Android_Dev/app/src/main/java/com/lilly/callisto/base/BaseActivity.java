package com.lilly.callisto.base;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProviders;

public abstract class BaseActivity<V extends ViewModel, D extends ViewDataBinding> extends AppCompatActivity {

    private V mViewModel;
    private D mViewDataBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mViewDataBinding = DataBindingUtil.setContentView(this, getLayoutRef());
        mViewModel = ViewModelProviders.of(this).get(getViewModelClass());
        mViewDataBinding.setVariable(getBindingVariable(), mViewModel);
        mViewDataBinding.setLifecycleOwner(this);
        mViewDataBinding.executePendingBindings();
        initViews();
    }

    protected abstract void initViews();

    protected abstract int getBindingVariable();

    protected abstract Class<V> getViewModelClass();

    protected abstract int getLayoutRef();

    @Override
    protected void onDestroy() {
        if(mViewDataBinding != null){
            mViewDataBinding.unbind();
        }
        super.onDestroy();
    }
}
