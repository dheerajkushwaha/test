package com.lilly.callisto.constants;

public class PreferenceConstants {
    public static final String ACCESS_KEY = "ACCESS_KEY";
    public static final String APP_PREF = "APP_PREF";
}
