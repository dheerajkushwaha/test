package com.lilly.callisto.featuremodules.onboard.participantlogin;

import android.app.Application;
import android.text.TextUtils;
import android.util.Log;

import com.lilly.callisto.comman.model.SignInReqModel;
import com.lilly.callisto.data.cloud.CloudRepo;
import com.lilly.callisto.utils.DeviceUtils;
import com.lilly.callisto.utils.NetworkUtil;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;
import io.reactivex.disposables.CompositeDisposable;

public class ParticipantLogInViewModel extends AndroidViewModel {

    private String mUserId;
    private String mPassword;
    private Application mApplication;
    private MutableLiveData<Boolean> mLoginStatus;
    private CompositeDisposable disposable = new CompositeDisposable();
    private static final String TAG = "ParticipantLogInViewMod";

    public ParticipantLogInViewModel(@NonNull Application application) {
        super(application);
        mApplication = application;
        mLoginStatus = new MutableLiveData<Boolean>();
    }

    public String getUserId() {
        return mUserId;
    }

    public void setUserId(String userId) {
        mUserId = userId;
    }

    public String getPassword() {
        return mPassword;
    }

    public void setPassword(String password) {
        mPassword = password;
    }

    public void doLogin() {

        if (isUserIdPasswordValid() && NetworkUtil.isNetworkConnected(mApplication.getApplicationContext())) {
            Log.i("==", "internet conncted");
            SignInReqModel signInReqModel = new SignInReqModel();
            signInReqModel.setUsername(getUserId());
            signInReqModel.setPassword(getPassword());
            signInReqModel.setDevice_id(DeviceUtils.getUDID(mApplication.getApplicationContext()));
            CloudRepo cloudRepo = new CloudRepo(mApplication.getApplicationContext());
            cloudRepo.verifyUser(signInReqModel);

            if (cloudRepo.verifyUser(signInReqModel) != null) {
                mLoginStatus.postValue(true);
            } else {
                mLoginStatus.postValue(false);
            }
       /* } else {
            mLoginStatus.postValue(false);
        }*/
        }
    }

    private boolean isUserIdPasswordValid() {
        if (TextUtils.isEmpty(getUserId()) || TextUtils.isEmpty(getPassword())) {
            return false;
        }
        return true;
    }

    public MutableLiveData<Boolean> getLoginStatus() {
        return mLoginStatus;
    }
}