package com.lilly.callisto.constants;

public class CloudConstants {
    public static final String BASE_URL = "https://mdit-callisto2.herokuapp.com/api/v1/";
    public static int REQUEST_TIMEOUT = 60;
}
