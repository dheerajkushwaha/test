package com.lilly.callisto.comman.model;

public class UserResModel {

    private String username;
    private String updated_at;
    private String inserted_at;
    private String id;
    private String device_id;


    // Getter Methods

    public String getUsername() {
        return username;
    }

    public String getUpdated_at() {
        return updated_at;
    }

    public String getInserted_at() {
        return inserted_at;
    }

    public String getId() {
        return id;
    }

    public String getDevice_id() {
        return device_id;
    }

    // Setter Methods

    public void setUsername(String username) {
        this.username = username;
    }

    public void setUpdated_at(String updated_at) {
        this.updated_at = updated_at;
    }

    public void setInserted_at(String inserted_at) {
        this.inserted_at = inserted_at;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setDevice_id(String device_id) {
        this.device_id = device_id;
    }
}
