package com.lnt.myapplication;


import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Singleton class to create retrofit instance singleton for making API calls
 */
public class APIClient {

    private static final String BASE_URL = "https://mdit-callisto2.herokuapp.com/api/v1/";

    private APIClient() {
    }

    private static final OkHttpClient okHttpClient = new OkHttpClient.Builder()
            .readTimeout(2, TimeUnit.MINUTES)
            .connectTimeout(2, TimeUnit.MINUTES)
            .build();

    private static Retrofit mRetrofit = new Retrofit.Builder().baseUrl(BASE_URL).client(okHttpClient).addConverterFactory(GsonConverterFactory.create()).build();

    public static <S> S createService(Class<S> serviceClass) {
        return mRetrofit.create(serviceClass);
    }
}
