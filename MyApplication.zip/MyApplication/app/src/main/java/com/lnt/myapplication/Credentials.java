package com.lnt.myapplication;

public class Credentials {
 private String token;
 private String expires_at;


 // Getter Methods 

 public String getToken() {
  return token;
 }

 public String getExpires_at() {
  return expires_at;
 }

 // Setter Methods 

 public void setToken(String token) {
  this.token = token;
 }

 public void setExpires_at(String expires_at) {
  this.expires_at = expires_at;
 }
}