package com.lnt.myapplication;

import android.os.Bundle;
import android.webkit.WebView;

import androidx.appcompat.app.AppCompatActivity;

public class TermsForUse extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms_for_use);
        WebView mWebView = findViewById(R.id.terms_for_use_wv);
        mWebView.loadUrl("file:///android_asset/terms_of_use.html");
    }
}
