package com.lnt.myapplication;

class ChatbotMessage {

    private String mMsg;
    private boolean mIsUser;
    private boolean mIsBackgroundWhite;
    private boolean mIsIconVisible;

    ChatbotMessage(String msg, boolean isUser, boolean isBackgroundWhite, boolean isIconVisible) {
        this.mMsg = msg;
        this.mIsUser = isUser;
        this.mIsBackgroundWhite = isBackgroundWhite;
        this.mIsIconVisible = isIconVisible;
    }

    String getMsg() {
        return mMsg;
    }

    boolean isUser() {
        return mIsUser;
    }

    boolean isBackgroundWhite() {
        return mIsBackgroundWhite;
    }

    boolean isIconVisible() {
        return mIsIconVisible;
    }
}