package com.lnt.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private TextView mUserAction;
    private ArrayList<ChatbotMessage> mItemList;
    private ItemArrayAdapter mItemArrayAdapter;
    private ArrayList<ChatbotMessage> mMessageList;
    private int mLoopStopPosition;
    private RecyclerView mRecyclerView;
    private int mDELAY = 1000;
    private static final String THREE_DOTS="...";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addMessagesToList();

        mUserAction = findViewById(R.id.user_action);
        mUserAction.setOnClickListener(this);

        mItemList = new ArrayList<>();
        mItemArrayAdapter = new ItemArrayAdapter(this, mItemList);

        mRecyclerView = findViewById(R.id.item_list);
        LinearLayoutManager mLayoutManager = new LinearLayoutManager(this);
        mLayoutManager.setStackFromEnd(true);
        mRecyclerView.setItemViewCacheSize(20);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mItemArrayAdapter);
        setMessages();
    }

    private synchronized void setMessages() {
        mItemList.add(new ChatbotMessage(THREE_DOTS, false, false, false));
        mItemArrayAdapter.notifyItemChanged(mLoopStopPosition);

        new Thread() {
            public void run() {
                try {
                    Thread.sleep(mDELAY);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mItemList.set(mLoopStopPosition, mMessageList.get(mLoopStopPosition));
                            mItemArrayAdapter.notifyItemChanged(mLoopStopPosition);
                            mRecyclerView.smoothScrollToPosition(mItemArrayAdapter.getItemCount() - 1);
                            startLoopingMesssage();
                        }
                    });
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    private synchronized void startLoopingMesssage() {
        mLoopStopPosition++;
        new Thread() {
            public void run() {
                for (int i = 0; i < mMessageList.size(); i++) {
                    try {
                        Thread.sleep(mDELAY);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (mMessageList.get(mLoopStopPosition).isUser()) {
                                    mUserAction.setVisibility(View.VISIBLE);
                                    mUserAction.setText(mMessageList.get(mLoopStopPosition).getMsg());
                                } else {
                                    boolean isBackgroundWhite = false;
                                    if (mLoopStopPosition == 1 || mLoopStopPosition == 5 || mLoopStopPosition == 10) {
                                        isBackgroundWhite = true;
                                    }
                                    mItemList.add(new ChatbotMessage(THREE_DOTS, false, isBackgroundWhite, false));
                                    mItemArrayAdapter.notifyItemChanged(mLoopStopPosition);
                                    mRecyclerView.smoothScrollToPosition(mItemArrayAdapter.getItemCount() - 1);
                                }
                            }
                        });
                        if (!mMessageList.get(mLoopStopPosition).isUser()) {
                            Thread.sleep(mDELAY);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    mItemList.set(mLoopStopPosition, mMessageList.get(mLoopStopPosition));
                                    mItemArrayAdapter.notifyItemChanged(mLoopStopPosition);
                                    mRecyclerView.smoothScrollToPosition(mItemArrayAdapter.getItemCount() - 1);
                                    mLoopStopPosition++;
                                }
                            });
                        } else {
                            break;
                        }

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }.start();
    }

    private void addMessagesToList() {
        mMessageList = new ArrayList<>();
        mMessageList.add(new ChatbotMessage("Welcome to Pilot, your personalized meal journal. Let’s get you set up.", false, false, false));
        mMessageList.add(new ChatbotMessage("First, your coordinator will help you set up some meals.", false, true, true));
        mMessageList.add(new ChatbotMessage("Let me know when you’re done.", false, false, false));
        mMessageList.add(new ChatbotMessage("I'm done with meal setup", true, false, false));
        mMessageList.add(new ChatbotMessage("Great! Now we need to set up a few permissions.", false, false, false));
        mMessageList.add(new ChatbotMessage("Your coordinator will explain why we want you to allow permissions.", false, true, true));
        mMessageList.add(new ChatbotMessage("We’ll send out the Health App Access permissions when you are ready.", false, false, false));
        mMessageList.add(new ChatbotMessage("I'm ready now", true, false, false));
        mMessageList.add(new ChatbotMessage("Awesome! Next, we’ll want to allow your location services.", false, false, false));
        mMessageList.add(new ChatbotMessage("For your security, your exact location will never be exposed.", false, false, false));
        mMessageList.add(new ChatbotMessage("Your coordinator will explain how we protect your data.", false, true, true));
        mMessageList.add(new ChatbotMessage("We’ll send out the location services permissions when you are ready.", false, false, false));
        mMessageList.add(new ChatbotMessage("I'm ready now", true, false, false));
    }

    @Override
    public void onClick(View view) {
        mItemList.add(mMessageList.get(mLoopStopPosition));
        mItemArrayAdapter.notifyItemChanged(mLoopStopPosition);
        mRecyclerView.smoothScrollToPosition(mItemArrayAdapter.getItemCount() - 1);
        mUserAction.setVisibility(View.INVISIBLE);
        RecyclerView.ViewHolder viewHolder = mRecyclerView.findViewHolderForAdapterPosition(mLoopStopPosition - 2);
        if (viewHolder != null) {
            View itemView = viewHolder.itemView;
            ImageView chatbotIcon = itemView.findViewById(R.id.chatbot_icon);
            TextView message = itemView.findViewById(R.id.received_msg_tv);
            LinearLayout receivedMsgLayout = itemView.findViewById(R.id.received_msg_parent);
            chatbotIcon.setColorFilter(getResources().getColor(R.color.white, null));
            message.setTextColor(getResources().getColor(R.color.white, null));
            receivedMsgLayout.setBackground(getResources().getDrawable(R.drawable.received_msg_background, null));
        }
        if (mLoopStopPosition == mMessageList.size() - 1) {
            mLoopStopPosition++;
            checkPermissions();
        } else {
            startLoopingMesssage();
        }

    }

    private void checkPermissions() {
        if (!LocationPermission.isLocationPermissionGranted(this)) {
            LocationPermission.requestLocationPermission(this);
        }
    }
}
