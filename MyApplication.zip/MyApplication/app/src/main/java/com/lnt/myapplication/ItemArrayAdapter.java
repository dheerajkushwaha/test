package com.lnt.myapplication;

import android.content.Context;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ItemArrayAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private ArrayList<ChatbotMessage> itemList;
    private Context mContext;
    private static final int USER = 0;
    private static final int CHATBOT = 1;
    private static final String THREE_DOTS = "...";
    private static final int TEN = 10;
    private static final int TWENTY = 20;
    private static final int TWO_HUNDRED = 200;

    ItemArrayAdapter(Context context, ArrayList<ChatbotMessage> itemList) {
        this.itemList = itemList;
        this.mContext = context;
    }

    @Override
    public int getItemCount() {
        return itemList == null ? 0 : itemList.size();
    }

    @Override
    public int getItemViewType(int position) {
        if (itemList.get(position).isUser()) {
            return USER;
        } else {
            return CHATBOT;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        if (viewType == USER) {
            View sentMsgView = inflater.inflate(R.layout.sent_msg_layout, parent, false);
            viewHolder = new SentMsgHolder(sentMsgView);
        } else {
            View receivedMsgView = inflater.inflate(R.layout.receive_msg_layout, parent, false);
            viewHolder = new ReceivedMsgHolder(receivedMsgView);
        }
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, final int position) {
        if (holder.getItemViewType() == USER) {
            SentMsgHolder sentMsgHolder = (SentMsgHolder) holder;
            setSentMsgHolder(sentMsgHolder, position);
        } else {
            ReceivedMsgHolder receivedMsgHolder = (ReceivedMsgHolder) holder;
            setReceivedMsgHolder(receivedMsgHolder, position);
        }
    }

    private void setSentMsgHolder(SentMsgHolder sentMsgHolder, int position) {
        TextView sentMsgTv = sentMsgHolder.mSentMsgTv;
        LinearLayout sentMsgLayout = sentMsgHolder.mSentMsgLayout;
        if (!itemList.get(position).getMsg().equals(THREE_DOTS)) {
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
            layoutParams.setMargins(TWO_HUNDRED, TWENTY, TWENTY, TWENTY);
            layoutParams.gravity = Gravity.END;
            sentMsgLayout.setLayoutParams(layoutParams);
            sentMsgLayout.setGravity(Gravity.START);
            sentMsgLayout.setPadding(TWENTY, TWENTY, TWENTY, TWENTY);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(TWENTY, TEN, TWENTY, TEN);
            sentMsgTv.setLayoutParams(params);
            sentMsgTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, TWENTY);
        }
        sentMsgTv.setText(itemList.get(position).getMsg());
        Animation a = AnimationUtils.loadAnimation(mContext, R.anim.right_to_left_anim);
        sentMsgHolder.itemView.setAnimation(a);
    }

    private void setReceivedMsgHolder(ReceivedMsgHolder receivedMsgHolder, int position) {
        TextView receivedMsgTv = receivedMsgHolder.mReceivedMsgTv;
        LinearLayout receivedMsgLayout = receivedMsgHolder.mReceivedMsgLayout;
        if (itemList.get(position).isBackgroundWhite()) {
            receivedMsgTv.setTextColor(mContext.getResources().getColor(R.color.black, null));
            receivedMsgLayout.setBackground(mContext.getResources().getDrawable(R.drawable.white_background, null));
        } else {
            receivedMsgTv.setTextColor(mContext.getResources().getColor(R.color.white, null));
            receivedMsgLayout.setBackground(mContext.getResources().getDrawable(R.drawable.received_msg_background, null));
        }
        if (!itemList.get(position).getMsg().equals(THREE_DOTS)) {
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            layoutParams.setMargins(TWENTY, TWENTY, TWO_HUNDRED, TWENTY);
            receivedMsgLayout.setLayoutParams(layoutParams);
            receivedMsgLayout.setPadding(TWENTY, TWENTY, TWENTY, TWENTY);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(TWENTY, TEN, TWENTY, TEN);
            receivedMsgTv.setLayoutParams(params);
            receivedMsgTv.setGravity(Gravity.NO_GRAVITY);
            receivedMsgTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, TWENTY);
        }
        receivedMsgTv.setText(itemList.get(position).getMsg());
        if (itemList.get(position).isIconVisible()) {
            receivedMsgHolder.mChatbotIcon.setVisibility(View.VISIBLE);
        } else {
            receivedMsgHolder.mChatbotIcon.setVisibility(View.GONE);
        }
        Animation a = AnimationUtils.loadAnimation(mContext, R.anim.left_to_right_anim);
        receivedMsgHolder.itemView.setAnimation(a);
    }

    class ReceivedMsgHolder extends RecyclerView.ViewHolder {
        private TextView mReceivedMsgTv;
        private LinearLayout mReceivedMsgLayout;
        private ImageView mChatbotIcon;

        ReceivedMsgHolder(View itemView) {
            super(itemView);
            mReceivedMsgTv = itemView.findViewById(R.id.received_msg_tv);
            mReceivedMsgLayout = itemView.findViewById(R.id.received_msg_parent);
            mChatbotIcon = itemView.findViewById(R.id.chatbot_icon);
        }
    }

    class SentMsgHolder extends RecyclerView.ViewHolder {
        private TextView mSentMsgTv;
        private LinearLayout mSentMsgLayout;

        SentMsgHolder(View itemView) {
            super(itemView);
            mSentMsgTv = itemView.findViewById(R.id.send_msg_tv);
            mSentMsgLayout = itemView.findViewById(R.id.sent_msg_parent);
        }
    }
}