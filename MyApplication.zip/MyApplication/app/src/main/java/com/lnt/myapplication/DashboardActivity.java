package com.lnt.myapplication;


import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.transition.Slide;
import androidx.transition.Transition;
import androidx.transition.TransitionManager;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import static com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_COLLAPSED;
import static com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_DRAGGING;
import static com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED;
import static com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_HIDDEN;
import static com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_SETTLING;

public class DashboardActivity extends AppCompatActivity {

    private FloatingActionButton mFloatingActionButton;
    private LinearLayout mDashboardBottomContentLayoutId;
    private LinearLayout mMealButtonLayoutId;
    private AppCompatButton mTestMealBtn;
    private AppCompatButton mCommonMealBtn;
    private TextView mDay;
    private TextView mDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dashboard_layout);
        mFloatingActionButton = findViewById(R.id.close_bottom_sheet_btn);
        mMealButtonLayoutId = findViewById(R.id.meal_buttons_layout_id);
        mTestMealBtn = findViewById(R.id.test_meal_btn);
        mCommonMealBtn = findViewById(R.id.common_meal_btn);
        mDay = findViewById(R.id.dashboard_bottom_content_title);
        mDate = findViewById(R.id.dashboard_bottom_content_sub_title);
        mDashboardBottomContentLayoutId = findViewById(R.id.dashboard_bottom_content_id);
        CoordinatorLayout.LayoutParams coordinatorLayoutParams = (CoordinatorLayout.LayoutParams) mFloatingActionButton.getLayoutParams();
        FloatingActionButton.Behavior fabBehavior = (FloatingActionButton.Behavior) coordinatorLayoutParams.getBehavior();
        if (fabBehavior != null) {
            fabBehavior.setAutoHideEnabled(false);
        } else {
            fabBehavior = new FloatingActionButton.Behavior();
            fabBehavior.setAutoHideEnabled(false);
            coordinatorLayoutParams.setBehavior(fabBehavior);
        }
        mFloatingActionButton.hide();
        BottomSheetBehavior mBottomSheetBehavior = BottomSheetBehavior.from(mDashboardBottomContentLayoutId);
        mBottomSheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View view, int newState) {
                switch (newState) {
                    case STATE_HIDDEN:
                        Log.e("STATE_HIDDEN", "STATE_HIDDEN");
                        break;
                    case STATE_EXPANDED:
                        break;
                    case STATE_COLLAPSED:
                        Log.e("STATE_COLLAPSED", "STATE_COLLAPSED");
                        break;
                    case STATE_DRAGGING:
                        Log.e("STATE_DRAGGING", "STATE_DRAGGING");
                        break;
                    case STATE_SETTLING:
                        Log.e("STATE_SETTLING", "STATE_SETTLING");
                        break;
                    case BottomSheetBehavior.STATE_HALF_EXPANDED:
                        Log.e("STATE_HALF_EXPANDED", "STATE_HALF_EXPANDED");
                        break;
                    default:
                        break;
                }
               /* if(newState==STATE_EXPANDED){
                    CoordinatorLayout.LayoutParams relativeParams = (CoordinatorLayout.LayoutParams)mLinearLayout.getLayoutParams();
                    relativeParams.setMargins(10, 100, 10, 0);
                    mLinearLayout.setLayoutParams(relativeParams);
                }*/
            }

            @Override
            public void onSlide(@NonNull View view, float offset) {
                if (offset > 0.6f) {
                    mFloatingActionButton.show();
                    //mFloatingActionButton.show();
                    mDay.setText("Wednesday");
                    mDate.setText("Aug 29,2018");
                } else {
                    mFloatingActionButton.hide();
                    mDay.setText("Meal Journal");
                    mDate.setText("Swipe up to view");
                }
                if (offset > 0.9f) {
                    /*CoordinatorLayout.LayoutParams coordinatorLayoutIdLayoutParams = (CoordinatorLayout.LayoutParams)mDashboardBottomContentLayoutId.getLayoutParams();
                    coordinatorLayoutIdLayoutParams.setMargins(10, 10, 10, 0);
                    mDashboardBottomContentLayoutId.setLayoutParams(coordinatorLayoutIdLayoutParams);
                    mMealButtonsLayout.setVisibility(View.GONE);*/

                   // viewAnimator(mMealButtonLayoutId);
                    mMealButtonLayoutId.setVisibility(View.GONE);
                } else if (offset < 0.8f) {
                    //viewAnimator(mMealButtonLayoutId);
                    mMealButtonLayoutId.setVisibility(View.VISIBLE);
                }
            }
        });
    }

    private void viewAnimator(View view) {
        Transition transition = new Slide(Gravity.BOTTOM);
        transition.setDuration(500);
        transition.addTarget(view);
        TransitionManager.beginDelayedTransition(mDashboardBottomContentLayoutId, transition);
    }
}
