package com.lnt.myapplication;

import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.google.android.material.textfield.TextInputEditText;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignInActivity extends AppCompatActivity {
    TextInputEditText mUser;
    TextInputEditText mPassword;
    AppCompatButton mSignInBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        mUser=findViewById(R.id.user_id_input_et);
        mPassword=findViewById(R.id.password_input_et);
        mSignInBtn=findViewById(R.id.appCompatButton);
        mSignInBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = mUser.getText() == null ? "" : mUser.getText().toString().trim();
                String password = mPassword.getText() == null ? "" : mPassword.getText().toString().trim();

                String mUDID = Settings.Secure.getString(getApplicationContext().getContentResolver(),
                        Settings.Secure.ANDROID_ID);
                SignInRequestModel signInRequestModel = new SignInRequestModel(user, password, mUDID);
                signIn(signInRequestModel);
            }
        });
    }

    public void signIn(SignInRequestModel signInRequestModel) {
        APIServices mApiServices = APIClient.createService(APIServices.class);
        Call<SignInBaseModel> signInBaseModelCall = mApiServices.signIn(signInRequestModel);
        signInBaseModelCall.enqueue(new Callback<SignInBaseModel>() {
            @Override
            public void onResponse(@NonNull Call<SignInBaseModel> call, @NonNull Response<SignInBaseModel> response) {
                try {
                    Log.e("response",response+"");
                } catch (Exception e) {
                    String tag ="TAG";
                    String errorMsg = "error";
                    Log.e(tag, e.getMessage() != null ? e.getMessage() : errorMsg);
                }
            }

            @Override
            public void onFailure(@NonNull Call<SignInBaseModel> call, @NonNull Throwable t) {
                Log.e("onFailure","onFailure"+"");
            }
        });
    }
}
