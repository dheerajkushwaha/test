package com.lnt.myapplication;

public class SignInBaseModel {
 private User user;
 private Credentials credentials;


 // Getter Methods 

 public User getUser() {
  return user;
 }

 public Credentials getCredentials() {
  return credentials;
 }

 // Setter Methods 

 public void setUser(User user) {
  this.user = user;
 }

 public void setCredentials(Credentials credentials) {
  this.credentials = credentials;
 }
}